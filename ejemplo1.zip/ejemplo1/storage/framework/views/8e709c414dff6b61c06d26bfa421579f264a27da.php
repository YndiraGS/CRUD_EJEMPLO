<?php
?>

BLADE (THE BETTER)
<table border="1">
    <tr>
        <td>NAME</td>
        <td>LAST NAME</td>
        <td>NUMBER</td>
        <td>ESTATUS</td>
        <td>BIRTHDAY</td>
    </tr>
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $color = ($client->status) ? 'gris' : 'red';
            //$classColor = ($client->status) ? '' : 'color-red';
            $classColor = ($client->status) ?: 'color-red';
        ?>
        <!--tr style='background-color: <?php echo e($color); ?>;' -->
        <tr class="<?php echo e($classColor); ?>">
            <td><?php echo e($client->fisrt_name); ?></td>
            <td><?php echo e($client->last_name); ?></td>
            <td><?php echo e($client->number); ?></td>
            <td><?php echo e($client->status); ?></td>
            <td><?php echo e($client->birthdate); ?></td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\laragon\www\ejemplo1\resources\views/clients/index.blade.php ENDPATH**/ ?>